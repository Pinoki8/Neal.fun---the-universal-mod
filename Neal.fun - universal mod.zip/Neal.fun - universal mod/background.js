chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === "complete" && tab.url) {
    if (tab.url.startsWith("https://neal.fun/") && tab.url === "https://neal.fun/") {
      // Główna strona Neal.fun
      fetch("https://raw.githubusercontent.com/Pinoki8/Neal.fun---the-universal-mod/refs/heads/main/mainpage")
        .then(response => response.text())
        .then(code => {
          chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: (scriptCode) => {
              // Use Function constructor instead of script tag to bypass CSP
              try {
                const fn = new Function(scriptCode);
                fn();
              } catch (e) {
                console.error("Error executing script:", e);
              }
            },
            args: [code],
            world: 'MAIN'
          });
        })
        .catch(err => console.error("Error loading mainpage script:", err));
    } 
    else if (tab.url.startsWith("https://neal.fun/infinite-craft/")) {
      // Infinite Craft
      fetch("https://raw.githubusercontent.com/Pinoki8/Neal-fun-infinite-craft-item-replacer/refs/heads/main/Code")
        .then(response => response.text())
        .then(code => {
          chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: (scriptCode) => {
              // Use Function constructor instead of script tag to bypass CSP
              try {
                const fn = new Function(scriptCode);
                fn();
              } catch (e) {
                console.error("Error executing script:", e);
              }
            },
            args: [code],
            world: 'MAIN'
          });
        })
        .catch(err => console.error("Error loading infinite-craft script:", err));
    }
    else if (tab.url.startsWith("https://neal.fun/asteroid-launcher/")) {
      fetch("https://raw.githubusercontent.com/Pinoki8/Neal.fun---the-universal-mod/refs/heads/main/asteroid-launcher")
        .then(response => response.text())
        .then(code => {
          chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: (scriptCode) => {
              // Use Function constructor instead of script tag to bypass CSP
              try {
                const fn = new Function(scriptCode);
                fn();
              } catch (e) {
                console.error("Error executing script:", e);
              }
            },
            args: [code],
            world: 'MAIN'
          });
        })
        .catch(err => console.error("Error loading infinite-craft script:", err));
    }
  }
});